import Axios from "axios";
import { useEffect, useState } from "react";

function API_1() {
    const [User, setUser] = useState([])

    const getData = () => {
        Axios.get("https://jsonplaceholder.typicode.com/users")
            .then((res) => {
                setUser(res.data);
                console.log(User);
            })
        }
        useEffect(() => {
            getData();
        }, [])

    

    return (
        <div className="API_1">
            <h1> This is the page of API_1</h1>
            <p>{User.map(i=> <h4>{i.name} - {i.address.city}</h4>)}</p>
        </div>
    )

}




export default API_1;