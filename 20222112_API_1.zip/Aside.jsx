const Aside = () => {
return ( 
  <div className="sideBar">
  <h1>API</h1>
  <ul>
    <li> API 1</li>
    <li> API 2</li>
    <li> API 3</li>
    <li> API 4</li>
    <li> API 5</li>
  </ul>
</div>
)
}




export default Aside;