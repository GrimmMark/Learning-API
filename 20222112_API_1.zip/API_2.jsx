const API_2 = () => {
    return ( 
    <div className="API_2">
      <h1>API_2</h1>
      
    </div>
    )
    }
    
    
    
    
    export default API_2;