import './App.css';
import Aside from './Aside.jsx';
import API_1 from "./API_1";
import API_2 from "./API_2";
import API_3 from "./API_3";
import API_4 from "./API_4";
import API_5 from "./API_5";
// import { useEffect, useState } from 'react';


function App() {


  return (
    <div className="App">

      <Aside />
      <div className='main'>
      <API_1 />
      <API_2 />
      <API_3 />
      <API_4 />
      <API_5 />
      </div>
    </div>
  );
}
export default App;
